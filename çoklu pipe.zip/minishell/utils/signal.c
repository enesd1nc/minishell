/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signal.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 19:05:35 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 19:06:58 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"
#include <sys/stat.h>
#include <signal.h>

void set_parent_handlers(void) 
{ 
	struct sigaction sa; 
	struct sigaction ign; 
	// SIGINT: satırı temizle 
	sigemptyset(&sa.sa_mask); 
	sa.sa_flags = SA_RESTART; 
	// readline için iyi 
	sa.sa_handler = parent_sigint_handler; 
	sigaction(SIGINT, &sa, NULL); // SIGQUIT: prompt'ta ignore 
	sigemptyset(&ign.sa_mask); 
	ign.sa_flags = 0; 
	ign.sa_handler = SIG_IGN; 
	sigaction(SIGQUIT, &ign, NULL);
 }


/* ---- EXEC SIRASINDA (CHILD ÇALIŞIRKEN) ---- */
void parent_ignore_exec_signals(void)
{
    struct sigaction ign;
    sigemptyset(&ign.sa_mask);
    ign.sa_flags = 0;
    ign.sa_handler = SIG_IGN;
    sigaction(SIGINT, &ign, NULL);
    sigaction(SIGQUIT, &ign, NULL);
}

void child_restore_default_signals(void)
{
    struct sigaction sa;

    /* SIGINT default */
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = SIG_DFL;
    sigaction(SIGINT, &sa, NULL);

    /* SIGQUIT için özel handler */
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = child_sigquit_handler;   // İstersen SIG_DFL bırak
    sigaction(SIGQUIT, &sa, NULL);
}


