/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_3.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 15:49:33 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 16:00:18 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int	handle_file_execution(t_local *local, t_env *envir, t_garbage **garb)
{
	int	exit_code;

	exit_code = execute(local->ast_root, envir, garb, 1);
	g_free_l(garb);
	return (exit_code);
}
