/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dollar_fix.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/28 18:11:29 by fses              #+#    #+#             */
/*   Updated: 2025/09/08 12:06:33 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft/libft.h"
#include "../minishell.h"
#include <stdlib.h>

static int	handle_dollar_var(char *cmd, int i, int *new_len, t_env *env)
{
	int		k;
	char	*val;

	k = 0;
	while (cmd[i + 1 + k] && (ft_isalnum((unsigned char)cmd[i + 1 + k]) || cmd[i
				+ 1 + k] == '_'))
		k++;
	if (k > 0)
	{
		val = get_env_cont_for_type(env, cmd + i + 1, k);
		if (val)
			(*new_len) += 1 + k;
		return (i + 1 + k);
	}
	else
	{
		(*new_len) += 1;
		return (i + 1);
	}
}

int	dollar_fix_len(char *cmd, t_env *env)
{
	t_local	local;

	local.i = 0;
	local.new_len = 0;
	while (cmd[local.i])
	{
		if (cmd[local.i] == '$')
		{
			if (cmd[local.i + 1] == '"' || cmd[local.i + 1] == '\'')
				local.i = handle_dollar_quote(cmd, local.i, &local.new_len);
			else if (cmd[local.i + 1] && is_ws((unsigned char)cmd[local.i + 1]))
			{
				local.new_len += 1;
				local.i += 1;
			}
			else
				local.i = handle_dollar_var(cmd, local.i, &local.new_len, env);
		}
		else
		{
			local.new_len++;
			local.i++;
		}
	}
	return (local.new_len);
}

static int	handle_dollar_var_write(char *cmd, t_local local, int *j,
		t_env *env)
{
	int		k;
	char	*val;

	k = 0;
	while (cmd[local.i + 1 + k] && (ft_isalnum((unsigned char)cmd[local.i + 1
					+ k]) || cmd[local.i + 1 + k] == '_'))
		k++;
	if (k > 0)
	{
		val = get_env_cont_for_type(env, cmd + local.i + 1, k);
		if (val)
		{
			local.result[(*j)++] = cmd[local.i++];
			while (k-- > 0)
				local.result[(*j)++] = cmd[local.i++];
		}
		else
			local.i += 1 + k;
	}
	else
		local.result[(*j)++] = cmd[local.i++];
	return (local.i);
}

static int	handle_dollar_cases(char *cmd, t_local local, int *j, t_env *env)
{
	if (cmd[local.i + 1] == '"' || cmd[local.i + 1] == '\'')
	{
		if (cmd[local.i + 2] == '\0')
			local.result[(*j)++] = cmd[local.i++];
		else
			local.i += 1;
	}
	else if (cmd[local.i + 1] && is_ws((unsigned char)cmd[local.i + 1]))
		local.result[(*j)++] = cmd[local.i++];
	else
		local.i = handle_dollar_var_write(cmd, local, j, env);
	return (local.i);
}

char	*dollar_fix(char *cmd, t_env *env, t_garbage **garb)
{
	int		j;
	int		new_len;
	t_local	local;

	j = 0;
	local.i = 0;
	if (!cmd)
		return (NULL);
	new_len = dollar_fix_len(cmd, env);
	local.result = (char *)malloc((size_t)new_len + 1);
	if (!local.result)
		return (NULL);
	g_collecter(garb, local.result, 1);
	while (cmd[local.i])
	{
		if (cmd[local.i] == '$')
			local.i = handle_dollar_cases(cmd, local, &j, env);
		else
			local.result[j++] = cmd[local.i++];
	}
	free(cmd);
	local.result[j] = '\0';
	return (local.result);
}
