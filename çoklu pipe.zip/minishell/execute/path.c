/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 18:54:08 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 18:55:45 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"

char	*normalize_path(const char *path, t_garbage **garb)
{
	size_t	i;
	size_t	j;
	size_t	n;
	size_t	cap;
	char	*out;

	if (!path)
		return (NULL);
	n = strlen(path);
	cap = (n * 2) + 3;
	out = (char *)malloc(cap);
	if (!out)
		return (NULL);
	g_collecter(garb, out, 1);
	i = 0;
	j = 0;
	while (i < n)
	{
		if (path[i] == ':')
		{
			if (i == 0 || path[i - 1] == ':')
				out[j++] = '.';
			out[j++] = ':';
		}
		else
			out[j++] = path[i];
		i++;
	}
	if (n > 0 && path[n - 1] == ':')
		out[j++] = '.';
	out[j] = '\0';
	return (out);
}

static size_t	join_len(const char *dir, const char *cmd)
{
	size_t	dlen;
	size_t	clen;
	int		need_slash;

	dlen = strlen(dir);
	clen = strlen(cmd);
	need_slash = 1;
	if (dlen > 0 && dir[dlen - 1] == '/')
		need_slash = 0;
	return (dlen + (size_t)need_slash + clen + 1);
}

static void	join_path(char *dst, const char *dir, const char *cmd)
{
	size_t	dlen;

	dst[0] = '\0';
	strcpy(dst, dir);
	dlen = strlen(dir);
	if (dlen == 0 || dst[dlen - 1] != '/')
		strcat(dst, "/");
	strcat(dst, cmd);
}

char	**split_dirs(char *norm, t_garbage **garb)
{
	char	**dirs;
	size_t	i;

	dirs = ft_split(norm, ':');
	if (!dirs)
		return (NULL);
	g_collecter(garb, dirs, 1);
	i = 0;
	while (dirs[i])
	{
		g_collecter(garb, dirs[i], 1);
		i++;
	}
	return (dirs);
}

char	*search_in_dirs(char **dirs, char *cmd, t_garbage **garb)
{
	size_t	i;
	size_t	flen;
	char	*full;

	i = 0;
	while (dirs && dirs[i])
	{
		flen = join_len(dirs[i], cmd);
		full = (char *)malloc(flen);
		if (!full)
			return (NULL);
		g_collecter(garb, full, 1);
		join_path(full, dirs[i], cmd);
		if (access(full, X_OK) == 0)
			return (full);
		i++;
	}
	return (NULL);
}
