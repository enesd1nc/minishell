#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"

static volatile int g_heredoc_interrupted = 0;

static void process_single_delimiter(char *key, t_post_order *post_order)
{
    char *txt;
    
    while (1)
    {
        txt = readline("> ");
        if (g_heredoc_interrupted || !txt || ft_strcmp(txt, key) == 0)
        {
            if(g_heredoc_interrupted)
                g_free(post_order->garb);
            free(txt);
            if (post_order->delimiter == 0)
                post_order->delimiter = 2;
            break;
        }
        free(txt);
    }
}

static int handle_preliminary_delimiters(t_ast *heredoc_node, t_post_order *post_order, int pipefd[2])
{
    char *key;
    int i = 0;

    while ((i < heredoc_node->delimiter_hr_count - 1 && heredoc_node->delimiter_hr[i]) || post_order->delimiter == 0 || heredoc_node->fake_heredoc == 1)
    {
        key = heredoc_node->delimiter_hr[i];
        if (key) 
            process_single_delimiter(key, post_order);
        if (g_heredoc_interrupted)
        {
            g_free(post_order->garb);
            close(pipefd[1]);
            exit(130);
        }
        if (!key)
            break;
        i++;
    }
    return 0;
}

static void process_final_delimiter(t_ast *heredoc_node, t_env *env, t_post_order *post_order, int pipefd[2])
{
    char *txt;
    char *key;

    if (heredoc_node->delimiter_hr[heredoc_node->delimiter_hr_count - 1] && post_order->delimiter == 1) 
    {
        key = heredoc_node->delimiter_hr[heredoc_node->delimiter_hr_count - 1];
        while (1)
        {
            txt = readline("> ");
            if (g_heredoc_interrupted || !txt || ft_strcmp(txt, key) == 0)
            {
                if(g_heredoc_interrupted)
                    g_free(post_order->garb);
                free(txt);
                break;
            }
            if (heredoc_node->was_quoted != 6 && heredoc_node->was_quoted != 7 && ft_strchr(txt, '$'))
            {
                char *expanded = mini_expend_dollar(env, txt, post_order->garb);
                free(txt);
                txt = expanded;
            }
            if (ft_strlen(txt) > 0)
                write(pipefd[1], txt, ft_strlen(txt));
            write(pipefd[1], "\n", 1);
            free(txt);
        }
    }
}

void heredoc_child_process(int pipefd[2], t_ast *heredoc_node, t_env *env, t_post_order *post_order)
{
    g_heredoc_interrupted = 0;
    signal(SIGINT, heredoc_interrupt_handler);
    signal(SIGQUIT, SIG_IGN);
    close(pipefd[0]);

    handle_preliminary_delimiters(heredoc_node, post_order, pipefd);
    
    process_final_delimiter(heredoc_node, env, post_order, pipefd);
    
    close(pipefd[1]);
    if (g_heredoc_interrupted)
    {
        g_free(post_order->garb);
        exit(130);
    }
    g_free(post_order->garb);
    exit(0);
}




int	execute_child_process(char *cmd_path, char **args, t_env *env,
			t_garbage **garb)
{
	pid_t	pid;
	int		status;
	int 	cat_flag;

	cat_flag = 0;
	pid = fork();
	if (pid == -1)
	{
		perror("fork");
		return (0);
	}
	parent_ignore_exec_signals();
	if(ft_strncmp(args[0],"./",1) != 0)
		cat_flag++;
	else
		cat_flag++;
	if (pid == 0)
	{
		child_restore_default_signals();
		if(cat_flag)
			g_heredoc_interrupted=getpid();
		execve(cmd_path, args, list_to_arr(env, garb));
		perror("execve");
		exit(1);
	}
	else
	{
		waitpid(pid, &status, 0);
		set_parent_handlers();
		return (ret_status(status));
	}
}


static void	read_until_delimiter(char *key)
{
	char	*txt;

	while (1)
	{
		txt = readline("> ");
		if (g_heredoc_interrupted || !txt)
			break ;
		if (ft_strcmp(txt, key) == 0)
		{
			free(txt);
			break ;
		}
		free(txt);
	}
}

void	process_regular_delimiters(t_ast *heredoc_node, int *i)
{
	char	*key;

	while (*i < heredoc_node->delimiter_hr_count - 1
		&& heredoc_node->delimiter_hr[*i])
	{
		key = heredoc_node->delimiter_hr[*i];
		if (key)
			read_until_delimiter(key);
		if (g_heredoc_interrupted)
			break ;
		(*i)++;
	}
}

static void	process_last_delimiter(t_ast *heredoc_node, t_env *env,
			t_garbage **garb, int pipefd)
{
	char	*txt;
	char	*key;

	key = heredoc_node->delimiter_hr[heredoc_node->delimiter_hr_count - 1];
	while (1)
	{
		txt = readline("> ");
		if (g_heredoc_interrupted || !txt)
			break ;
		if (ft_strcmp(txt, key) == 0)
		{
			free(txt);
			break ;
		}
		txt = expand_if_needed(heredoc_node, env, txt, garb);
		write_line_to_pipe(txt, pipefd);
	}
}

void	handle_child_process(t_ast *heredoc_node, t_env *env,
			t_garbage **garb, int pipefd[2])
{
	int	i;

	i = 0;
	close(pipefd[0]);
	signal(SIGINT, heredoc_interrupt_handler);
	signal(SIGQUIT, SIG_IGN);
	process_regular_delimiters(heredoc_node, &i);
	if (heredoc_node->delimiter_hr[heredoc_node->delimiter_hr_count - 1]
		&& !g_heredoc_interrupted)
		process_last_delimiter(heredoc_node, env, garb, pipefd[1]);
	close(pipefd[1]);
	if (g_heredoc_interrupted)
	{
		g_free(garb);
		exit(130);
	}
	g_free(garb);
	exit(0);
}

int	exec_pipe_node(t_ast *node, t_env *env, t_garbage **garb)
{
	int		pipefd[2];
	pid_t	pid1;
	pid_t	pid2;
	char	*heredoc_file;
	int		special_result;
	t_post_order	post_order;

	g_heredoc_interrupted = 0;
	special_result = handle_special_cases(node, env, garb);
	if (special_result != -1)
		return (special_result);
	heredoc_file = create_heredoc_if_needed(node, env, garb);
	if (node->left && node->left->type == NODE_HEREDOC && !heredoc_file)
		return (130);
	if (pipe(pipefd) == -1)
	{
		perror("pipe");
		if (heredoc_file)
			unlink(heredoc_file);
		return (1);
	}
	post_order.garb = garb;
	post_order.heredoc_file = heredoc_file;
	pid1 = fork_left_process(node, env, &post_order,pipefd);
	if (pid1 == -1)
		return (1);
	post_order.garb = garb;
	post_order.heredoc_file = heredoc_file;
	pid2 = fork_right_process(node, env, &post_order, pipefd);
	if (pid2 == -1)
		return (1);
	return (wait_processes_and_cleanup(pid1, pid2, heredoc_file, pipefd));
}

