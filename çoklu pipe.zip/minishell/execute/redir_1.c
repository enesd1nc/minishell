/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redir_1.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 18:04:48 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 18:05:03 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"


static int	open_output_file(t_ast *node, int append)
{
	int	fd;
	int	flags;

	flags = O_CREAT | O_WRONLY;
	if (append)
		flags |= O_APPEND;
	else
		flags |= O_TRUNC;
	fd = open(node->filename, flags, 0644);
	if (fd < 0)
	{
		printf("minishell: %s: Permission denied\n", node->filename);
		return (-1);
	}
	return (fd);
}

static int	exec_with_fork(t_ast *node, t_env *env,
				t_garbage **garb, int fd)
{
	pid_t	pid;
	int		status;
	int		result;

	pid = fork();
	if (pid < 0)
	{
		perror("fork");
		close(fd);
		return (1);
	}
	if (pid == 0)
	{
		dup2(fd, STDOUT_FILENO);
		close(fd);
		result = execute(node->left, env, garb, 1);
		g_free(garb);
		exit(result);
	}
	close(fd);
	waitpid(pid, &status, 0);
	return (ret_status(status));
}

int	exec_redirect_out(t_ast *node, t_env *env, int append,
			t_garbage **garb)
{
	int		fd;
	t_ast	*temp;
	int		check;
	int		heredoc_result;
	t_post_order	post_order;

	check = 0;
	temp = node;
	set_multi_flags(node);
	temp = node;
	if (node->left->type == NODE_REDIR_IN && node->multi_flag == 0)
	{
		check = 1;
		handle_fake_heredocs(node, env, garb, append);
	}
	post_order.garb = garb;
	post_order.append = append;
	post_order.check = check;
	heredoc_result = check_and_handle_heredocs(node, env, &post_order);
	if (heredoc_result != -1)
		return (heredoc_result);
	fd = open_output_file(node, append);
	if (fd < 0)
		return (0);
	if (node->multi_flag == 0)
		return (exec_with_fork(node, env, garb, fd));
	else
	{
		close(fd);
		return (execute(node->left, env,garb, 1));
	}
}

int	process_heredocs(t_ast *node, t_env *env,
				t_garbage **garb, int *fake)
{
	t_ast	*temp;
	int		flag;
	int		result;

	temp = node;
	flag = 0;
	result = 0;
	while (temp && temp->left)
	{
		if (temp->left->fake_heredoc == 1)
			*fake = 1;
		if (temp->left->type == NODE_HEREDOC && temp->left->fake_heredoc == 0)
		{
			flag = 1;
			temp->left->fake_heredoc = 1;
			result = execute(temp->left, env, garb, 0);
		}
		temp = temp->left;
	}
	return (flag);
}

void	set_multi_redir_flags(t_ast *node)
{
	t_ast	*temp;

	temp = node;
	while (temp && temp->left)
	{
		temp->left->multi_redir = 1;
		temp = temp->left;
	}
}
