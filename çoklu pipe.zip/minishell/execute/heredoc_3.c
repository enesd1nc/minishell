/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc_3.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 18:26:16 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/09 09:33:13 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"

static int	is_redirection_node(t_ast *node)
{
	if (!node)
		return (0);
	return (node->type == NODE_HEREDOC);
}

int	handle_special_cases(t_ast *node, t_env *env,
			t_garbage **garb)
{
	int	has_left_heredoc;
	int	has_right_heredoc;
	
	check_heredoc_status(node, &has_left_heredoc, &has_right_heredoc);
	if (has_right_heredoc && has_left_heredoc)
	{
		execute(node->left, env, garb, 0);
		return (execute(node->right, env ,garb, 1));
	}
	if (is_redirection_node(node->right))
	{
		execute(node->right, env, garb, 1);
		if (node->left && node->left->filename)
			return (execute(node->left, env, garb, 1));
		return (1);
	}
	return (-1);
}

char	*create_heredoc_if_needed(t_ast *node, t_env *env,
			t_garbage **garb)
{
	char	*heredoc_file;

	if (!node->left || node->left->type != NODE_HEREDOC)
		return (NULL);
	signal(SIGINT, SIG_IGN);
	heredoc_file = create_heredoc_temp_file(node->left, env, garb);
	if (!heredoc_file)
		set_parent_handlers();
	else
		set_parent_handlers();
	return (heredoc_file);
}

static void	setup_heredoc_fd(char *heredoc_file)
{
	int	fd;

	if (!heredoc_file)
		return ;
	fd = open(heredoc_file, O_RDONLY);
	if (fd < 0)
	{
		perror("open heredoc file");
		exit(1);
	}
	dup2(fd, STDIN_FILENO);
	close(fd);
}

void	execute_left_child(t_ast *node, t_env *env,
			 int pipefd[2], t_post_order *post_order)
{
	int	result;

	setup_heredoc_fd(post_order->heredoc_file);
	dup2(pipefd[1], STDOUT_FILENO);
	close(pipefd[0]);
	close(pipefd[1]);
	
	if (node->left && node->left->type == NODE_HEREDOC)
	{
		// Heredoc'un child'ını execute et (cat komutunu)
		result = execute(node->left->left, env, post_order->garb, 1);
	}
	else
	{
		result = execute(node->left, env, post_order->garb, 1);
	}
	
	g_free(post_order->garb);
	exit(result);
}
