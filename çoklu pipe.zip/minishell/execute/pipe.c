/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipe.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 18:13:50 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/09 09:42:11 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"

static volatile int g_heredoc_interrupted = 0;

static pid_t	fork_left_process(t_ast *node, t_env *env,
			t_post_order *post_order, int pipefd[2])
{
	pid_t	pid1;

	pid1 = fork();
	if (pid1 < 0)
	{
		perror("fork (left)");
		close(pipefd[0]);
		close(pipefd[1]);
		if (post_order->heredoc_file)
			unlink(post_order->heredoc_file);
		return (-1);
	}
	if (pid1 == 0)
		execute_left_child(node, env, pipefd, post_order);
	return (pid1);
}

static void	execute_right_child(t_ast *node, t_env *env,
			t_garbage **garb, int pipefd[2])
{
	int	result;

	dup2(pipefd[0], STDIN_FILENO);
	close(pipefd[0]);
	close(pipefd[1]);
	result = execute(node->right, env, garb, 1);
	g_free(garb);
	exit(result);
}

static pid_t	fork_right_process(t_ast *node, t_env *env,
			t_post_order *post_order, int pipefd[2])
{
	pid_t	pid2;

	pid2 = fork();
	if (pid2 < 0)
	{
		perror("fork (right)");
		close(pipefd[0]);
		close(pipefd[1]);
		if (post_order->heredoc_file)
			unlink(post_order->heredoc_file);
		return (-1);
	}
	if (pid2 == 0)
		execute_right_child(node, env, post_order->garb, pipefd);
	return (pid2);
}

static int	wait_processes_and_cleanup(pid_t pid1, pid_t pid2,
			char *heredoc_file, int pipefd[2])
{
	int	status;

	close(pipefd[0]);
	close(pipefd[1]);
	waitpid(pid1, NULL, 0);
	waitpid(pid2, &status, 0);
	if (heredoc_file)
		unlink(heredoc_file);
	return (ret_status(status));
}

int	exec_pipe_node(t_ast *node, t_env *env, t_garbage **garb)
{
	int		pipefd[2];
	pid_t	pid1;
	pid_t	pid2;
	char	*heredoc_file;
	int		special_result;
	t_post_order	post_order;

	g_heredoc_interrupted = 0;
	
	if (node->right->type == NODE_PIPE)
	{
		execute(node->left, env, garb, 0);
		return (execute(node->right, env, garb, 1));
	}
	
	special_result = handle_special_cases(node, env, garb);
	if (special_result != -1)
		return (special_result);
	heredoc_file = create_heredoc_if_needed(node, env, garb);
	if (node->left && node->left->type == NODE_HEREDOC && !heredoc_file)
		return (130);
	if (pipe(pipefd) == -1)
	{
		perror("pipe");
		if (heredoc_file)
			unlink(heredoc_file);
		return (1);
	}
	post_order.garb = garb;
	post_order.heredoc_file = heredoc_file;
	pid1 = fork_left_process(node, env, &post_order,pipefd);
	if (pid1 == -1)
		return (1);
	post_order.garb = garb;
	post_order.heredoc_file = heredoc_file;
	pid2 = fork_right_process(node, env, &post_order, pipefd);
	if (pid2 == -1)
		return (1);
	return (wait_processes_and_cleanup(pid1, pid2, heredoc_file, pipefd));
}
