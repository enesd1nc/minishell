/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc_2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 17:50:12 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 19:27:22 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"

static volatile int g_heredoc_interrupted = 0;

static void process_single_delimiter(char *key, t_post_order *post_order)
{
    char *txt;
    
    while (1)
    {
        txt = readline("> ");
        if (g_heredoc_interrupted || !txt || ft_strcmp(txt, key) == 0)
        {
            if(g_heredoc_interrupted)
                g_free(post_order->garb);
            free(txt);
            if (post_order->delimiter == 0)
                post_order->delimiter = 2;
            break;
        }
        free(txt);
    }
}

static int handle_preliminary_delimiters(t_ast *heredoc_node, t_post_order *post_order, int pipefd[2])
{
    char *key;
    int i = 0;

    while ((i < heredoc_node->delimiter_hr_count - 1 && heredoc_node->delimiter_hr[i]) || post_order->delimiter == 0 || heredoc_node->fake_heredoc == 1)
    {
        key = heredoc_node->delimiter_hr[i];
        if (key) 
            process_single_delimiter(key, post_order);
        if (g_heredoc_interrupted)
        {
            g_free(post_order->garb);
            close(pipefd[1]);
            exit(130);
        }
        if (!key)
            break;
        i++;
    }
    return 0;
}

static void process_final_delimiter(t_ast *heredoc_node, t_env *env, t_post_order *post_order, int pipefd[2])
{
    char *txt;
    char *key;

    if (heredoc_node->delimiter_hr[heredoc_node->delimiter_hr_count - 1] && post_order->delimiter == 1) 
    {
        key = heredoc_node->delimiter_hr[heredoc_node->delimiter_hr_count - 1];
        while (1)
        {
            txt = readline("> ");
            if (g_heredoc_interrupted || !txt || ft_strcmp(txt, key) == 0)
            {
                if(g_heredoc_interrupted)
                    g_free(post_order->garb);
                free(txt);
                break;
            }
            if (heredoc_node->was_quoted != 6 && heredoc_node->was_quoted != 7 && ft_strchr(txt, '$'))
            {
                char *expanded = mini_expend_dollar(env, txt, post_order->garb);
                free(txt);
                txt = expanded;
            }
            if (ft_strlen(txt) > 0)
                write(pipefd[1], txt, ft_strlen(txt));
            write(pipefd[1], "\n", 1);
            free(txt);
        }
    }
}

void heredoc_child_process(int pipefd[2], t_ast *heredoc_node, t_env *env, t_post_order *post_order)
{
    g_heredoc_interrupted = 0;
    signal(SIGINT, heredoc_interrupt_handler);
    signal(SIGQUIT, SIG_IGN);
    close(pipefd[0]);

    handle_preliminary_delimiters(heredoc_node, post_order, pipefd);
    
    process_final_delimiter(heredoc_node, env, post_order, pipefd);
    
    close(pipefd[1]);
    if (g_heredoc_interrupted)
    {
        g_free(post_order->garb);
        exit(130);
    }
    g_free(post_order->garb);
    exit(0);
}
