/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 17:32:07 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 17:46:36 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>



static void setup_heredoc_child_io(int *pipefd, t_ast *node, t_post_order *post_order)
{
    int i;
    int flags;
    int outfd;

    dup2(pipefd[0], STDIN_FILENO);
    close(pipefd[0]);
    
    if (post_order->redir == 1 && post_order->output_file)
    {
        i = 0;
        while (i < node->files_count_rdr - 1)
        {
            int fd = open(node->files_rdr[i], O_CREAT, 0644);
            if (fd < 0) 
            {
                perror("dosya oluşturulamadı");
                exit(1);
            }	
            close(fd);
            i++;
        }
        
        flags = O_CREAT | O_WRONLY;
        if (post_order->append)
            flags |= O_APPEND;
        else
            flags |= O_TRUNC;
            
        outfd = open(post_order->output_file, flags, 0644);
        if (outfd < 0)
        {
            perror("open (heredoc redirect)");
            exit(1);
        }
        
        dup2(outfd, STDOUT_FILENO);
        close(outfd);
    }
}

static void execute_heredoc_command(t_ast *heredoc_node, t_env *env, t_garbage **garb)
{
    int result;

    if (heredoc_node->fake_heredoc == 1)
        result = 1;
    if (heredoc_node->left && heredoc_node->fake_heredoc == 0)
        result = execute(heredoc_node->left, env, garb, 1);
    if (heredoc_node->left && heredoc_node->left->type == NODE_CMD)
    {
        result = execute(heredoc_node->left, env, garb, 1);
        g_free(garb);
        exit(result);
    }
    else
        result = 0;
    g_free(garb);
    exit(result);
}

static void handle_command_child_process(t_ast *node,t_env *env, t_exec_context *exec)
{
    setup_heredoc_child_io(exec->pipefd, node, exec->post_order);
    execute_heredoc_command(exec->heredoc_node, env,  exec->garb);
}

static int fork_and_execute_command(t_ast *node, t_env *env, t_exec_context *exec)
{
    pid_t cmd_pid;
    int status;

    cmd_pid = fork();
    if (cmd_pid == -1)
    {
        perror("fork command");
        close(exec->pipefd[0]);
        return 1;
    }
    
    if (cmd_pid == 0)
    {
        handle_command_child_process(node, env, exec);
    }
    
    close(exec->pipefd[0]);
    waitpid(cmd_pid, &status, 0);
    
    if (WIFEXITED(status))
        return WEXITSTATUS(status);
    else if (WIFSIGNALED(status))
        return 128 + WTERMSIG(status);
    
    return 1;
}

int exec_heredoc_node(t_ast *node, t_env *env, t_garbage **garb, 
                     t_post_order *post_order)
{
    int pipefd[2];
    t_ast *heredoc_node;
	pid_t heredoc_pid;
	t_exec_context	exec;

    if (pipe(pipefd) == -1)
    {
        perror("pipe");
        return 1;
    }
    heredoc_node = find_heredoc_node(node, post_order);
    if (validate_and_setup_heredoc(heredoc_node, pipefd) != 0)
        return 1;
    heredoc_pid = create_heredoc_process(pipefd);
    if (heredoc_pid == -1)
        return 1;
    post_order->garb = garb;
    if (heredoc_pid == 0)
        heredoc_child_process(pipefd, heredoc_node, env, post_order);
    int heredoc_result = heredoc_parent_process(heredoc_pid, pipefd);
    if (heredoc_result == 130)
    {
        return 130;
    }
	exec.pipefd = pipefd;
	exec.post_order = post_order;
	exec.heredoc_node = heredoc_node;
	exec.garb = garb;
    return fork_and_execute_command(node, env, &exec);
}
