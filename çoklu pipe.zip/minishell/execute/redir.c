/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redir.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 17:59:49 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 18:00:18 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"

static int	open_input_file(t_ast *node)
{
	int	fd;

	fd = open(node->filename, O_RDONLY);
	if (fd < 0)
	{
		printf("minishell: no such file or directory: %s\n", node->filename);
		return (-1);
	}
	return (fd);
}

static int	execute_with_heredoc_logic(t_ast *node, t_env *env,
				t_garbage **garb, int flag)
{
	int	result;

	if (flag == 0)
	{
		if (node->left->fake_heredoc == 0)
			result = execute(node->left, env, garb, 1);
		if (node->left->fake_heredoc == 1)
			result = execute(node->left->left, env, garb, 1);
	}
	else
	{
		result = execute(node->left->left, env, garb, 0);
	}
	return (result);
}

static int	exec_with_fork_input(t_ast *node, t_env *env,
				t_post_order *post_order)
{
	pid_t	pid;
	int		status;
	int		result;

	pid = fork();
	if (pid < 0)
	{
		perror("fork");
		close(post_order->fd);
		return (1);
	}
	if (pid == 0)
	{
		dup2(post_order->fd, STDIN_FILENO);
		close(post_order->fd);
		result = execute_with_heredoc_logic(node, env, post_order->garb, post_order->flag);
		g_free(post_order->garb);
		exit(result);
	}
	close(post_order->fd);
	waitpid(pid, &status, 0);
	return (ret_status(status));
}

static int	execute_without_fork(t_ast *node, t_env *env,
				t_garbage **garb)
{
	if (node->left->fake_heredoc == 0 || node->left->type != NODE_HEREDOC)
		return (execute(node->left, env, garb, 1));
	if (node->left->fake_heredoc == 1 && node->left->type == NODE_HEREDOC)
		return (execute(node->left->left, env, garb, 1));
	return (0);
}

int	exec_redirect_in(t_ast *node, t_env *env, t_garbage **garb)
{
	int	fd;
	int	flag;
	int	fake;
	t_post_order	post_order;

	fake = 0;
	flag = process_heredocs(node, env, garb, &fake);
	set_multi_redir_flags(node);
	fd = open_input_file(node);
	if (fd < 0)
		return (1);
	if ((node->multi_redir == 0 && node->delimiter_hr_count == 0)
		|| flag == 1 || fake == 1)
	{
		post_order.fd = fd;
		post_order.flag = flag;
		post_order.garb = garb;
		return (exec_with_fork_input(node, env, &post_order));
	}
	else
	{
		close(fd);
		return (execute_without_fork(node, env, garb));
	}
}
