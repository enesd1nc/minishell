/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cmd.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 18:43:22 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/08 19:26:51 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include "../libft/libft.h"
#include <sys/stat.h>

static volatile int g_heredoc_interrupted = 0;

char	*find_command_path(char *cmd, t_garbage **garb, t_env *env)
{
	char	*path;
	char	*norm;
	char	**dirs;

	if (!cmd)
		return (NULL);
	if (strchr(cmd, '/'))
	{
		if (access(cmd, X_OK) == 0)
			return (g_collecter(garb, strdup(cmd), 1));
		perror(cmd);
		return (NULL);
	}
	path = get_env_path(list_to_arr(env, garb));
	if (!path)
		return (NULL);
	norm = normalize_path(path, garb);
	if (!norm)
		return (NULL);
	dirs = split_dirs(norm, garb);
	if (!dirs)
		return (NULL);
	return (search_in_dirs(dirs, cmd, garb));
}

int ret_status(int status)
{
     if (WIFEXITED(status))
            return WEXITSTATUS(status);
        else if (WIFSIGNALED(status))
            return 128 + WTERMSIG(status); 
        return 1; 
}
static int	validate_command_path(const char *path, char *cmd, char *cmd_path)
{
	struct stat	st;

	if (!ft_strchr(cmd, '/') && !cmd_path)
	{
		printf("%s: command not found\n", cmd);
		return (127);
	}
	if (stat(path, &st) == -1)
	{
		printf("minishell: %s: No such file or directory\n", path);
		return (127);
	}
	if (S_ISDIR(st.st_mode))
	{
		printf("minishell: %s: Is a directory\n", path);
		return (126);
	}
	if (access(path, X_OK) == -1)
	{
		printf("minishell: %s: Permission denied\n", path);
		return (126);
	}
	if (!cmd_path)
	{
		if (ft_strncmp(cmd, "./", 1) != 0)
			printf("minishell: %s: command not found\n", cmd);
		return (127);
	}
	return (0);
}

static int	execute_child_process(char *cmd_path, char **args, t_env *env,
			t_garbage **garb)
{
	pid_t	pid;
	int		status;
	int 	cat_flag;

	cat_flag = 0;
	pid = fork();
	if (pid == -1)
	{
		perror("fork");
		return (0);
	}
	parent_ignore_exec_signals();
	if(ft_strncmp(args[0],"./",1) != 0)
		cat_flag++;
	else
		cat_flag++;
	if (pid == 0)
	{
		child_restore_default_signals();
		if(cat_flag)
			g_heredoc_interrupted=getpid();
		execve(cmd_path, args, list_to_arr(env, garb));
		perror("execve");
		exit(1);
	}
	else
	{
		waitpid(pid, &status, 0);
		set_parent_handlers();
		return (ret_status(status));
	}
}

int	exec_cmd_node(t_ast *node, t_env *env, t_garbage **garb)
{
	char		*cmd;
	int			has_slash;
	char		*cmd_path;
	const char	*path;
	int			validation_result;

	if (!node || !node->args)
		return (0);
	if (is_builtin(node->args[0]))
		return (exec_builtin(node->args, env, garb));
	cmd = node->args[0];
	has_slash = (ft_strchr(cmd, '/') != NULL);
	cmd_path = find_command_path(node->args[0], garb,env);
	path = has_slash ? cmd : cmd_path;
	validation_result = validate_command_path(path, cmd, cmd_path);
	if (validation_result != 0)
		return (validation_result);
	return (execute_child_process(cmd_path, node->args, env, garb));
}
