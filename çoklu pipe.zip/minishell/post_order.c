#include "minishell.h"
#include "libft/libft.h"
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

static volatile int g_heredoc_interrupted = 0;

void heredoc_interrupt_handler(int signum)
{
    (void)signum;
    g_heredoc_interrupted = 1;
    write(STDOUT_FILENO, "\n", 1);
    close(STDIN_FILENO);
}

void parent_sigint_handler(int sig)
{
    (void)sig;
	
    write(1, "\n", 1);
    rl_on_new_line();
    rl_replace_line("", 0);
    rl_redisplay();
}

void child_sigquit_handler(int sig)
{
    (void)sig;
	pid_t g_child_pid ;

	g_child_pid = (pid_t)g_heredoc_interrupted;
    if (g_child_pid && kill(g_child_pid, SIGTERM) == -1) 
	{
        perror("kill");
    }
	else if(!g_child_pid)
	{
        // Prompt'tayız: satırı temizle + yeni satır
        write(STDOUT_FILENO, "\n", 1);
        rl_on_new_line();
        rl_replace_line("", 0);
        rl_redisplay();
	}
    // veya sadece sessiz geçebilirsin
}



/* ================== SENİN MAIN ================== */




int execute(t_ast *node, t_env *env,t_garbage **garb, int delimiter)
{
	t_post_order	post_order;

	post_order.append = 0;
	post_order.redir = 0;
	post_order.output_file = NULL;
	post_order.delimiter = delimiter;
    if (!node)
        return (0);
    if (node->type == NODE_CMD && !get_env_cont_for_type(env,"PATH",4) && !is_builtin(node->args[0]))
    {
        ft_putstr_fd("minishell: ",2);
        ft_putstr_fd(node->args[0],2);
        ft_putstr_fd(": No such file or directory\n\n",2);
        return 127;
    }
    if (node->type == NODE_HEREDOC)
		return exec_heredoc_node(node, env, garb, &post_order);
    else if (node->type == NODE_REDIR_IN || node->type == NODE_REDIR_OUT || node->type == NODE_REDIR_APPEND)
        return exec_redirect_node(node, env, garb);
    else if (node->type == NODE_PIPE)
        return exec_pipe_node(node, env, garb);
    else if (node->type == NODE_CMD)
        return exec_cmd_node(node, env, garb);
    
    return (0);
}
