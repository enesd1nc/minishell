/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 15:57:55 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/15 07:41:22 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft/libft.h"
#include "ft_printf/ft_printf.h"
#include "minishell.h"
#include <readline/history.h>
#include <readline/readline.h>

int	process_line(t_local *local, int exit_code)
{
	add_history(local->s);
	local->s = expend_question(exit_code, local->s, &local->garb);
	if (!local->s)
		return (1);
	local->s = dollar_fix(local->s, local->envir, &local->garb);
	if (!local->s)
		return (1);
	local->s = more_space(local->s, &local->garb);
	if (!local->s)
		return (1);
	return (0);
}

int	handle_command_execution(t_local *local, char **env, int current_exit_code)
{
	int	exit_code;

	(void)current_exit_code;
	if (quote_check(local->s))
	{
		exit_code = process_input(local->s, local->envir, env, &local->garb);
		return (exit_code);
	}
	else
	{
		ft_printf("Syntax error: Unclosed quotes\n");
		return (2);
	}
}

int	shell_loop(t_local *local, char **env)
{
	int	exit_code;

	exit_code = 0;
	while (1)
	{
		local->s = readline("minishell> ");
		if (!local->s)
		{
			printf("exit\n");
			break ;
		}
		if (handle_empty_input(local))
			continue ;
		if (process_line(local, exit_code))
			return (1);
		exit_code = handle_command_execution(local, env, exit_code);
		if (exit_code > 255 && exit_code <= 1000)
		{
			if (exit_code >= 1000)
				exit_code = 1;
			break ;
		}
	}
	return (exit_code);
}

int	fake_loop(void)
{
	char	*s;

	while (1)
	{
		s = readline("minishell> ");
		if (!s)
		{
			printf("exit\n");
			break ;
		}
		ft_putstr_fd("minishell :permission denied\n", 2);
	}
	if (!s)
		return (0);
	return (1);
}

int	main(int ac, char **av, char **env)
{
	t_local	local;

	(void)av;
	(void)ac;
	local.exit = 0;
	set_parent_handlers();
	using_history();
	if (env[0] == NULL)
		return (fake_loop());
	local.garb = NULL;
	local.envir = split_env(env, &local.garb);
	if (!local.envir)
	{
		g_free(&local.garb);
		return (1);
	}
	local.exit = shell_loop(&local, env);
	if (local.exit == 1)
	{
		g_free(&local.garb);
		return (1);
	}
	g_free(&local.garb);
	clear_history();
	return (local.exit);
}
