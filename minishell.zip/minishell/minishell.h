/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mdinc <mdinc@student.42kocaeli.com.tr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/08 16:19:39 by mdinc             #+#    #+#             */
/*   Updated: 2025/09/15 09:53:06 by mdinc            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include <signal.h>

# define LESS 1
# define DLESS 2
# define PIPE 3
# define GREAT 4
# define DGREAT 5

typedef enum e_node_type
{
	NODE_CMD,
	NODE_PIPE,
	NODE_REDIR_IN,
	NODE_REDIR_OUT,
	NODE_REDIR_APPEND,
	NODE_HEREDOC
}						t_node_type;

typedef struct s_garbage
{
	void				*adress;
	struct s_garbage	*next;
	int					line;
	int					is_env;
}						t_garbage;

typedef struct s_post_order
{
	int					append;
	int					redir;
	char				*output_file;
	int					delimiter;
	int					fd;
	int					flag;
	int					check;
	char				*heredoc_file;
	t_garbage			**garb;
	char				*key;
}						t_post_order;

typedef struct s_ast
{
	t_node_type			type;
	char				**args;
	char				*filename;
	char				**delimiter_hr;
	char				**files_rdr;
	int					files_count_rdr;
	int					is_expended;
	int					delimiter_hr_count;
	int					was_quoted;
	int					multi_flag;
	int					multi_redir;
	struct s_ast		*left;
	struct s_ast		*right;
	int					fake_heredoc;
}						t_ast;

typedef struct s_lexer
{
	char				*str;
	int					token;
	int					i;
	int					is_expended;
	int					was_quoted;
	struct s_lexer		*next;
}						t_lexer;

typedef struct s_env
{
	char				*type;
	char				*content;
	struct s_env		*next;
}						t_env;

typedef struct s_shell
{
	t_lexer				*lex;
	t_env				*env;
	t_ast				*ast;
}						t_shell;

typedef struct s_exec_context
{
	int					*pipefd;
	t_ast				*node;
	t_ast				*heredoc_node;
	t_env				*env;
	char				**envir;
	t_garbage			**garb;
	t_post_order		*post_order;
}						t_exec_context;

typedef struct s_local
{
	int					l;
	int					q;
	int					quote_count;
	int					i;
	int					total;
	int					k;
	char				*val;
	int					o;
	int					out_len;
	char				*out;
	int					j;
	int					start_i;
	t_lexer				*root;
	t_lexer				*iter;
	int					token_len;
	int					consumed_len;
	int					was_quoted;
	int					is_expended;
	int					old_token;
	t_env				*root_env;
	t_env				*iter_env;
	char				*str;
	int					new_len;
	t_lexer				*lexer_root;
	t_env				*envir;
	t_ast				*ast_root;
	t_garbage			*garb;
	char				*s;
	int					flag;
	char				*result;
	char				*cmd;
	int					*is_expanded1;
	char				*dst;
	int					*b;
	int					*p;
	int					*c;
	t_lexer				*prev;
	const char			*st;
	int					exit;
}						t_local;

typedef struct s_quote
{
	int					old_token;
	const char			*s;
	int					*i;
	char				*st;
}						t_quote;

typedef struct s_parser
{
	int					files_count;
	int					delimiter_count;
	char				**delimiter;
	char				**files;
	int					first;
	t_garbage			**garb;
}						t_parser;

typedef struct s_redir
{
	int					delimiter;
	int					redir_in;
	pid_t				pid1;
	pid_t				pid2;
	char				*heredoc_file;
	int					check;
	int					heredoc_result;
	int					fd;
	int					append;
}						t_redir;
typedef struct s_dollar
{
	size_t				*l;
	char				q;
	char				*ret;
	char				*cmd;
	t_ast				*node;
	t_env				*env;
	t_garbage			**garb;
	int					redir_in;
}						t_dollar;

typedef struct s_child
{
	int					cat_flag;
	char				*cmd_path;
}						t_child;

t_ast					*parse_tokens(t_lexer *tokens, t_garbage **garb);
int						exec_cmd_node(t_ast *node, t_env *env,
							t_garbage **garb);
int						execute(t_ast *node, t_env *env, t_garbage **garb,
							t_redir *redir);
int						exec_pipe_node(t_ast *node, t_env *env,
							t_garbage **garb);
int						exec_redirect_node(t_ast *node, t_env *env,
							t_garbage **garb, int redir_in);
char					*create_heredoc_temp_file(t_ast *heredoc_node,
							t_env *env, t_garbage **garb);
char					*get_env_type_for_cont(t_env *env, char *cont, int n);
char					*mini_expend_dollar(t_env *env, char *src,
							t_garbage **garb);
char					*get_env_cont_for_type(t_env *env, const char *type,
							int n);
int						builtin_export(char **cmd, t_env **env,
							t_garbage **garb);
int						env_len(char *env, int t);
void					env_cpy(char *type, char *content, const char *env);
void					*g_collecter(t_garbage **garb, void *adress,
							int l_flag);
void					g_free_l(t_garbage **garb);
void					g_free(t_garbage **garb);
int						syntax_check(t_lexer *tokens, int *flag);
void					new_process(t_lexer *tokens);
int						file_check(t_lexer *tokens);
void					*g_collecter_env(t_garbage **garb, void *adress);
void					set_parent_handlers(void);
void					parent_ignore_exec_signals(void);
void					child_restore_default_signals(void);
char					*ft_itoa(int num);
char					*expend_question(int exit_code, char *s,
							t_garbage **garb);
int						is_ws(char c);
char					*dollar_fix(char *cmd, t_env *env, t_garbage **garb);
t_lexer					*lexer(char *cmd, t_env *envir, t_garbage **garb);
void					repair_expand(t_lexer **root, t_env *env,
							t_garbage **garb);
void					lex_clean(t_lexer **root);
char					*more_space(char *cmd, t_garbage **garb);
t_lexer					*lexer(char *cmd, t_env *envir, t_garbage **garb);
int						get_len(char *str, int i, t_env *env, int old_token);
int						token(char *str);
t_env					*split_env(char **env, t_garbage **garb);
void					assign_lex_cpy(t_local *local, int *was_quoted_ptr,
							int *is_expended, int i);
int						handle_escape_char(char *dst, char *src, int *i,
							int *l);
int						handle_quote_block(int *i, t_local *local, t_env *env,
							int *was_quoted_ptr);
void					expand_dollar(t_local local, t_env *env, char *src,
							int *is_expanded);
void					expand_tilda(int *l, int *i, t_env *env, t_local local);
int						is_var_char(int c);
void					envir_len(char *str, int *i, int *l, t_env *env);
void					tilda_len(char *str, int *l, int *i, t_env *env);
void					dq_env_expand(int *i, int *l, t_env *env,
							t_quote quote);
int						handle_heredoc_preprocessing(t_lexer **tokens,
							t_lexer **last_heredoc);
t_ast					*handle_redirection_tokens(t_lexer **tokens,
							t_garbage **garb);
int						handle_word_token(t_lexer **tokens, t_ast **cmd_node,
							t_garbage **garb);
void					handle_redir_node(t_ast **cmd_node, t_ast *redir_node,
							t_parser *parser);
t_ast					*create_cmd_node(t_lexer **tokens, t_garbage **garb);
int						add_argument_to_cmd(t_ast *cmd_node, char *arg,
							t_garbage **garb);
int						count_delimiters(t_lexer *tokens);
int						count_output_files(t_lexer *tokens);
char					**create_files_array(t_lexer *tokens, int files_count,
							t_garbage **garb);
char					**create_delimiter_array(t_lexer *tokens,
							int delimiter_count, t_garbage **garb);
t_ast					*create_ast_node(t_node_type type, t_garbage **garb);
t_ast					*create_redir_node(t_node_type type, t_lexer **tokens,
							t_garbage **garb);
t_lexer					*handle_heredoc_sequence(t_lexer *tokens);
int						handle_output_redirect(t_lexer *tokens);
int						handle_input_redirect(t_lexer *tokens);
int						count_command_args(t_lexer *tokens);
int						populate_args_array(t_ast *node, t_lexer *current,
							int arg_count, t_garbage **garb);
int						check_redirect_permissions(t_ast *node);
int						handle_dollar_quote(char *cmd, int i, int *new_len);
void					counter_expand(int *total, int *i);
int						skip_escaped(const char *s, int *i, int *l);
void					process_tilde_env_or_char(int *i, t_local *local,
							t_env *env, int old_token);
int						skip_ws(const char *str, int i, int t);
int						try_tilde_or_env(t_local *local, int *i, int *l,
							t_env *env);
int						exec_heredoc_node(t_ast *node, t_env *env,
							t_garbage **garb, t_post_order *post_order);
int						process_line(t_local *local, int exit_code);
int						handle_input_validation(t_local *local);
int						quote_check(const char *cmd);

int						handle_valid_syntax(t_local *local, t_env *envir,
							t_garbage **garb);
int						handle_exit_command(t_local *local, t_env *envir,
							t_garbage **garb);
int						handle_file_execution(t_local *local, t_env *envir,
							t_garbage **garb);
int						process_input(char *s, t_env *envir, char **env,
							t_garbage **garb);
int						handle_empty_input(t_local *local);
int						initialize_and_lex(char *s, t_env *envir,
							t_garbage **garb, t_local *local);
int						is_all_ws(char *str);

char					**list_to_arr(t_env *env, t_garbage **garb);
int						builtin_punctuation(char **args);
int						builtin_exit(char **cmd);
int						builtin_echo(char **cmd);
int						builtin_cd(char **cmd, t_env **env, t_garbage **garb);
int						builtin_pwd(t_garbage **garb, t_env *env);
int						builtin_unset(char **cmd, t_env **env);
int						builtin_env(char **cmd, t_env *env);
int						builtin_export(char **cmd, t_env **env,
							t_garbage **garb);
int						count_env_list(t_env *env);
int						fill_env_array(char **arr, t_env *env,
							t_garbage **garb);
int						export_out(t_env *env, t_garbage **garb);
size_t					calculate_env_string_length(t_env *env_node);
int						env_remove(char *type, t_env **env);
int						env_add(char *type, char *content, t_env **env,
							t_garbage **garb);
int						allocate_content(char **content, char *cmd, char *type);
int						handle_no_equal_sign(char *cmd, t_env **env,
							t_garbage **garb);
int						handle_invalid_export(char *cmd);
int						is_valid_export(char *str);

void					heredoc_child_process(int pipefd[2],
							t_ast *heredoc_node, t_env *env,
							t_post_order *post_order);
int						heredoc_parent_process(pid_t heredoc_pid,
							int pipefd[2]);
t_ast					*find_heredoc_node(t_ast *node,
							t_post_order *post_order);
int						validate_and_setup_heredoc(t_ast *heredoc_node,
							int *pipefd);
pid_t					create_heredoc_process(int *pipefd);
int						exec_redirect_out(t_ast *node, t_env *env, int append,
							t_garbage **garb);
int						exec_redirect_in(t_ast *node, t_env *env,
							t_garbage **garb, int redir_in);
void					heredoc_interrupt_handler(int signum);
int						process_heredocs(t_ast *node, t_env *env,
							t_garbage **garb, int *fake);
void					set_multi_redir_flags(t_ast *node);
int						ret_status(int status);
void					set_multi_flags(t_ast *node);
int						check_and_handle_heredocs(t_ast *node, t_env *env,
							t_post_order *post_order);
void					handle_fake_heredocs(t_ast *node, t_env *env,
							t_garbage **garb, int append);
int						handle_special_cases(t_ast *node, t_env *env,
							t_garbage **garb);
void					execute_left_child(t_ast *node, t_env *env,
							int pipefd[2], t_post_order *post_order);
char					*create_heredoc_if_needed(t_ast *node, t_env *env,
							t_garbage **garb);
void					check_heredoc_status(t_ast *node, int *has_left,
							int *has_right);
int						setup_heredoc_pipe(int pipefd[2], t_ast *heredoc_node);
char					*create_temp_filename(t_garbage **garb);
void					handle_child_process(t_ast *heredoc_node, t_env *env,
							t_garbage **garb, int pipefd[2]);
int						handle_parent_process(int pipefd[2], pid_t heredoc_pid);
int						write_pipe_to_file(char *temp_file, int pipefd);
void					process_regular_delimiters(t_ast *heredoc_node, int *i);
char					*expand_if_needed(t_ast *heredoc_node, t_env *env,
							char *txt, t_garbage **garb);
char					*normalize_path(const char *path, t_garbage **garb);
char					**split_dirs(char *norm, t_garbage **garb);
char					*search_in_dirs(char **dirs, char *cmd,
							t_garbage **garb);
char					*get_env_path(char **envp);
int						is_builtin(char *cmd);
int						exec_builtin(char **cmd, t_env *env, t_garbage **garb);
void					parent_sigint_handler(int sig);
void					child_sigquit_handler(int sig);
int						global_access(int change, int data);
int						is_redirection_node(t_ast *node);
int						check_redir_in(t_ast *node);
int						ft_strcmp(const char *s1, const char *s2);
t_dollar				*init_dollar(char *cmd, t_garbage **garb);
size_t					process_path_normalization(const char *path, char *out,
							size_t n);
void					process_single_delimiter(char *key,
							t_post_order *post_order);
int						validate_command_path(const char *path, char *cmd,
							char *cmd_path);
pid_t					fork_right_process(t_ast *node, t_env *env,
							t_post_order *post_order, int pipefd[2]);
pid_t					fork_left_process(t_ast *node, t_env *env,
							t_post_order *post_order, int pipefd[2]);
int						exec_with_fork(t_ast *node, t_env *env,
							t_garbage **garb, int fd);
int						exec_with_fork_input(t_ast *node, t_env *env,
							t_post_order *post_order);
int						open_output_file(t_ast *node, int append);
int						execute_without_fork(t_ast *node, t_env *env,
							t_garbage **garb);
int						open_input_file(t_ast *node);
void					handle_output_redirection(t_ast *node,
							t_post_order *post_order);
char					*find_command_path(char *cmd, t_garbage **garb,
							t_env *env);

#endif